define(['jquery', 'https://valeravilks.ru/boev/main.js?v='+Math.random()], function ($) {
  return amokit
});